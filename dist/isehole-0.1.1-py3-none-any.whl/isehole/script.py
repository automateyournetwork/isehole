from .isehole import cli
def run():
    cli()